# IMDb Sort Episodes By Rating
 IMDb extension for sorting episodes by rating
